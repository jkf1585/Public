#!/bin/bash

if [[ $UID != 0 ]]; then
echo "You must be Root!"
exit 1
fi

apt update -y

snap install netbeans --classic

snap list netbeans
