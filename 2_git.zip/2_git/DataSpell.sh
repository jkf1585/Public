#!/bin/bash

if [[ $UID != 0 ]]; then
echo "You must be Root!"
exit 1
fi

apt update -y

apt install snapd -y 

snap install dataspell --classic

