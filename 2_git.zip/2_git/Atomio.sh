#!/bin/bash

if [[ $UID != 0 ]]; then
echo "You must be Root!"
exit 1
fi

apt update -y

wget -qO - https://packagecloud.io/AtomEditor/atom/gpgkey | sudo apt-key add -

sh -c 'echo "deb [arch=amd64] https://packagecloud.io/AtomEditor/atom/any/ any main" > /etc/apt/sources.list.d/atom.list'

apt install atom* -y

