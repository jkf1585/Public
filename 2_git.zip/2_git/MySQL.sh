#!/bin/bash

if [[ $UID != 0 ]]; then
echo "You must be Root!"
exit 1
fi

apt update -y

apt-get install mysql-server -y 

systemctl is-active mysql

