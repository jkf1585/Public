#!/bin/bash

if [[ $UID != 0 ]]; then
echo "You must be Root!"
exit 1
fi

apt update -y

java -version

apt install default-jre -y

apt install default-jdk -y

java -version
