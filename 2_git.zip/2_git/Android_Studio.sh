#!/bin/bash

if [[ $UID != 0 ]]; then
echo "You must be Root!"
exit 1
fi

apt update -y

apt install openjdk-11-jdk -y 

add-apt-repository ppa:maarten-fonville/android-studio -y 

apt update

apt install android-studio -y

